Information
**************
	-> This is a fully packaged java solution for the given requirement. It works in Windows env.
	-> No dependency of additional jar/exe files to run this 
	-> Everything is packaged with this project.
	-> Runner file is a batch file, 'run_amazonCart.bat', located in Interview folder
	-> In the batch file default browser is given as 'Chrome'
    -> We can give any browser name as parameter, but I could not test with Firefox browser. Hence, with all conditions, It will default to chrome.
	-> Runner starts with compiling the source (compile.bat). If we want to compile after any changes, then we have to provide the java bin path in compiler.bat file.

To Run
***************	
1. Unzip Interview.rar file to 'Interview' folder
1. Click on the batch file (run_amazonCart.bat), which is located in Interview folder.
2. It will internally sets all dependencies, and starts a TestNG execution, which is configured in Interview/InterviewProjectAmazon/testng.xml
3. The TestNG project has three Test methods.
	-> navigateToAmazon, searchBrand & addToCartOnlyBestSeller
4. After the execution, the default testNG report will be created in Interview/test-output folder
	