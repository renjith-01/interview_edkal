package test_shoping;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertNotNull;

import java.io.File;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class AmazonAddToCartBestSeller {

  public static WebDriver driver;
  public static String amazon_url 			= "http://www.amazon.com";
  public static String searchItem 			= "headphones";
  int filteredSearchResultCount				= 0;
  
  public static String loc_searchBox 				= "twotabsearchtextbox";
  public static String loc_searchButton				= "//input[@type='submit' and @value='Go']";
  public static String loc_filterBestSelling 		= "//div[@class='a-section a-spacing-medium']//span[@class='a-badge-text' and text()='Best Seller']//..//..//..//..//..//..//..//..//..//div[2]/div/div/div/span/a";
  public static String loc_addToCartButton			= "add-to-cart-button";
  public static String loc_cart						= "//span[@id='nav-cart-count']";
  
  public static String loc_baseAddCartMessage		= "//div[@id='huc-v2-order-row-confirm-text']//h1[@class='a-size-medium a-text-bold']";
  public static String loc_cartItem					= "//span[@id='attach-accessory-cart-total-string']";
  public static String loc_extendedAddCartMessage	= "//div[@id='attachDisplayAddBaseAlert']//h4[@class='a-alert-heading']";
  public static String loc_sideSheetCloseButton		= "//a[@id='attach-close_sideSheet-link' and @class='a-link-normal close-button']";
  
  public static String loc_cartPage					= "//a[@id='nav-cart']";
  public static String loc_cartSubTotal				= "//span[@id='sc-subtotal-label-activecart']";
  public static String loc_cartCount				= "//a [@id='nav-cart']//span[@id='nav-cart-count']";
  public static String loc_cartSubTotalMessage		= "//span[@id='sc-subtotal-label-activecart' and @class='a-size-medium sc-number-of-items']";
  
  @Parameters("browser")
  @BeforeTest
  public void setupTest(String browser) throws InterruptedException {
	  System.out.println("Browser:" + browser);
	  initWebDriver(browser);
  }
  
  @AfterTest
  public void tearDownTest() {
	  driver.close();
	  driver.quit();
  }
	
  @Test
  public void navigateToAmazon() {
	  driver.manage().deleteAllCookies();
	  driver.get(amazon_url);
  }
  
  @Test(priority=1)
  public void searchBrand() {
	  List<WebElement> fullSearchResults;
	  driver.findElement(By.id(loc_searchBox)).sendKeys(searchItem);
	  driver.findElement(By.xpath(loc_searchButton)).click();
	  String searchResultsXpath="//div[contains(@data-cel-widget, 'search_result')]";
	  fullSearchResults = driver.findElements(By.xpath(searchResultsXpath));
	  //driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	  assertNotNull(fullSearchResults);
  }
  
  @Test(priority=2)
  public void addToCartOnlyBestSeller() throws InterruptedException {
	  WebElement addToCartButton;
	  WebDriverWait wait;
	  List<WebElement> filteredSearchResults = driver.findElements(By.xpath(loc_filterBestSelling));
	  filteredSearchResultCount = filteredSearchResults.size();
	  	  
	  System.out.println("Total Best Selling Items: " + filteredSearchResultCount);
	  
	  if(filteredSearchResultCount >0) {
		  for(int i=0; i<filteredSearchResultCount; i++) {
			  
			  WebElement bestSellingItem=filteredSearchResults.get(i);
			  bestSellingItem.click();
			  
			  wait = new WebDriverWait(driver, 3);
			  wait.until(ExpectedConditions.elementToBeClickable(addToCartButton = driver.findElement(By.id(loc_addToCartButton))));
			  wait.pollingEvery(Duration.ofSeconds(1));
			  
			  addToCartButton.click();
			  
			  Thread.sleep(3000);
			  driver.switchTo().activeElement();
			  WebElement closeShopingCartDialogueBox = null;
			  try {
				
				  wait = new WebDriverWait(driver, 3);
				  wait.until(ExpectedConditions.visibilityOf((closeShopingCartDialogueBox = driver.findElement(By.xpath(loc_sideSheetCloseButton)))));
				  driver.switchTo().activeElement();
			  	
			  }catch(NoSuchElementException ex) {
				  
				  closeShopingCartDialogueBox = null;
			  }
			  
			  if( closeShopingCartDialogueBox!= null ) {
				  WebElement cartTotal;
				  System.out.println("Clicking the accessory suegestion window ...");
				  
				  wait = new WebDriverWait(driver, 3);
				  wait.until(ExpectedConditions.visibilityOf(cartTotal = driver.findElement(By.xpath(loc_cartItem))));
				  wait.pollingEvery(Duration.ofSeconds(1));
				  
				  String addToCartMessage = driver.findElement(By.xpath(loc_extendedAddCartMessage)).getText();
				  assertEquals(addToCartMessage, "Added to Cart");
				  closeShopingCartDialogueBox.click();
  
			  }
			  else {
				  
				  WebElement addToCartMsgElement;
				  wait = new WebDriverWait(driver, 2);
				  wait.until(ExpectedConditions.visibilityOf(addToCartMsgElement = driver.findElement(By.xpath(loc_baseAddCartMessage))));
				  wait.pollingEvery(Duration.ofSeconds(1));
				  
				  String addToCartMessage = addToCartMsgElement.getText();
				  
				  assertEquals(addToCartMessage, "Added to Cart");
				  int addedCount = Integer.parseInt(driver.findElement(By.xpath(loc_cart)).getText());
				  
			  
			  }
			  
			  driver.navigate().back();
			  driver.navigate().back();
			  
			  driver.switchTo().activeElement();
			  filteredSearchResults = driver.findElements(By.xpath(loc_filterBestSelling));
			  			  
		  }
		  
		  Thread.sleep(2000);
		  
		  WebElement cartPageIcon;
		  wait = new WebDriverWait(driver, 4);
		  wait.until(ExpectedConditions.elementToBeClickable(cartPageIcon = driver.findElement(By.xpath(loc_cartPage))));
		  wait.pollingEvery(Duration.ofSeconds(1));
		  
		  cartPageIcon.click();
		  wait = new WebDriverWait(driver, 3);
		  wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(loc_cartSubTotal))));
		  wait.pollingEvery(Duration.ofSeconds(1));
		  
		  //Thread.sleep(5000);
		  
		  int cartItemsCount = Integer.parseInt(driver.findElement(By.xpath(loc_cartCount)).getText());
		  
		  
		  String expected_cartMessage = "Subtotal (" + filteredSearchResultCount + " items):";
		  
		  String actual_cartMessage = driver.findElement(By.xpath(loc_cartSubTotalMessage)).getText();
		  assertEquals(cartItemsCount, filteredSearchResultCount);
		  assertEquals(actual_cartMessage, expected_cartMessage);
		
	  }
	  else {
		  assertEquals(false, true, "No best selling items found !!!");
	  }
	  
	  
	  
  }
  
  static void initWebDriver(String browser) throws InterruptedException{
		
      //create chrome instance
		switch(browser.toUpperCase()) {
			case "CHROME":{
				System.out.println("Chrome browser is selected");
				System.out.println("Current working directory: " + System.getProperty("user.dir"));
				System.setProperty("webdriver.chrome.driver","InterviewProjectAmazon\\lib\\chromedriver.exe");
				ChromeOptions chromeOptions = new ChromeOptions();
		        chromeOptions.addArguments("disable-infobars");
		        chromeOptions.addArguments("start-maximized");
		        chromeOptions.addArguments("--disable-application-cache");

	            driver = new ChromeDriver(chromeOptions);

	            break;
			}
			case "FIREFOX":{
				System.out.println("Firefox browser is selected");
				
				System.out.println("Could not test with Firefox Driver !!! Hence defaulting to Chrome Driver ...");
				ChromeOptions chromeOptions = new ChromeOptions();
		        chromeOptions.addArguments("disable-infobars");
		        chromeOptions.addArguments("start-maximized");
		        chromeOptions.addArguments("--disable-application-cache");
				System.setProperty("webdriver.chrome.driver","InterviewProjectAmazon\\lib\\chromedriver.exe");
	            driver = new ChromeDriver();
				
				break;
			}
			
			default:{
				System.out.println("Default browser[Chrome] is selected");
				ChromeOptions chromeOptions = new ChromeOptions();
		        chromeOptions.addArguments("disable-infobars");
		        chromeOptions.addArguments("start-maximized");
		        chromeOptions.addArguments("--disable-application-cache");
				System.setProperty("webdriver.chrome.driver","InterviewProjectAmazon\\lib\\chromedriver.exe");
	            driver = new ChromeDriver();
			}
      
		}
  }
  
}
